% Run all the demos, to check everything is "syntactically correct"
mhmm_em_demo
dhmm_em_demo
dhmm_em_online_demo
fixed_lag_smoother_demo
